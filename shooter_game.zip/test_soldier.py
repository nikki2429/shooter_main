import unittest
import pygame
from shooter_tut13 import Soldier  # Import only the Soldier class

class TestSoldier(unittest.TestCase):
    def setUp(self):
        pygame.init()
        self.soldier = Soldier('player', 100, 100, 1.65, 5, 20, 5)

    def tearDown(self):
        pygame.quit()

    def test_initial_health(self):
        """Test that a new Soldier starts with the correct health"""
        self.assertEqual(self.soldier.health, 100, "Initial health should be 100")

    def test_movement_left(self):
        """Test that the player moves left correctly"""
        initial_x = self.soldier.rect.x
        self.soldier.move(True, False)  # Move left
        self.assertLess(self.soldier.rect.x, initial_x, "Player should move left")

    def test_movement_right(self):
        """Test that the player moves right correctly"""
        initial_x = self.soldier.rect.x
        self.soldier.move(False, True)  # Move right
        self.assertGreater(self.soldier.rect.x, initial_x, "Player should move right")

    def test_jump(self):
        """Test that the player jumps correctly"""
        initial_y = self.soldier.rect.y
        self.soldier.jump = True
        self.soldier.move(False, False)
        self.assertLess(self.soldier.rect.y, initial_y, "Player should move up when jumping")

    def test_shooting_reduces_ammo(self):
        """Test that shooting reduces ammo count"""
        initial_ammo = self.soldier.ammo
        self.soldier.shoot()
        self.assertEqual(self.soldier.ammo, initial_ammo - 1, "Ammo should decrease after shooting")

    def test_health_decrease(self):
        """Test that health decreases when damaged"""
        self.soldier.health -= 10
        self.assertEqual(self.soldier.health, 90, "Health should decrease when taking damage")

    def test_death(self):
        """Test that the player dies when health reaches 0"""
        self.soldier.health = 0
        self.soldier.check_alive()
        self.assertFalse(self.soldier.alive, "Soldier should be dead when health is 0")

if __name__ == '__main__':
    unittest.main()
